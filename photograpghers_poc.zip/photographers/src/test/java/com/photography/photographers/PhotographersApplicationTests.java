package com.photography.photographers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotographersApplicationTests {

	@Test
	void contextLoads() {
	}

}
