package com.photography.photographers.serviceimpl;

import org.springframework.stereotype.Service;

@Service
public class PhotoGrapherServiceImpl {

}
