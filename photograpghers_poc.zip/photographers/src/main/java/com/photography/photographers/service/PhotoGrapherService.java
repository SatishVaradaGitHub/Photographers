package com.photography.photographers.service;

public interface PhotoGrapherService {

}
