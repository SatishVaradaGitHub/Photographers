package com.usersbooking.user.service;

public interface UserBookingService {

}
